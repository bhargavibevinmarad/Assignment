package com.test;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.test.dto.TelephoneDialPad;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import static org.testng.Assert.assertEquals;

public class TelephoneDialPadTest {

    @DataProvider(name = "testCases")
    public Object[][] getTestCases() throws IOException {
        String excelFilePath = System.getProperty("user.dir")+"//test_cases.xlsx";
        FileInputStream fis = new FileInputStream(excelFilePath);
        Workbook workbook = new XSSFWorkbook(fis);
        Sheet sheet = workbook.getSheetAt(0);

        List<Object[]> data = new LinkedList<>();
        for (int i = 1; i <= sheet.getLastRowNum(); i++) { // Skip the header row
            Row row = sheet.getRow(i);
            if (row != null) {
                String input = getCellValueAsString(row.getCell(2));
                String expectedOutput = getCellValueAsString(row.getCell(3));
                data.add(new Object[]{input, expectedOutput.trim()});
            }
        }
        workbook.close();
        fis.close();
        return data.toArray(new Object[0][0]);
    }

    private String getCellValueAsString(Cell cell) {
        if (cell == null) {
            return "";
        }
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                return String.valueOf((int) cell.getNumericCellValue());
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                return cell.getCellFormula();
            default:
                return "";
        }
    }

    @Test(dataProvider = "testCases")
    public void testRetrieveCombinations(String input, String expectedOutput) {
        LinkedList<String> actualOutput = TelephoneDialPad.retrieveCombinations(input);
        assertEquals(actualOutput.toString(), expectedOutput);
    }

    @Test
    public void testEmptyInput() {
        LinkedList<String> actualOutput = TelephoneDialPad.retrieveCombinations("");
        assertEquals(actualOutput.toString(), "[]");
    }

    @Test
    public void testNullInput() {
        LinkedList<String> actualOutput = TelephoneDialPad.retrieveCombinations(null);
        assertEquals(actualOutput.toString(), "[]");
    }
}
