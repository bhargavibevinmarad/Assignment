package com.test.dto;

import java.util.LinkedList;
import java.util.List;

public class TelephoneDialPad {

    private static final String[][] DIAL_PAD_MAP = {
        {"0"}, {"1"}, {"A", "B", "C"}, {"D", "E", "F"}, {"G", "H", "I"},
        {"J", "K", "L"}, {"M", "N", "O"}, {"P", "Q", "R", "S"},
        {"T", "U", "V"}, {"W", "X", "Y", "Z"}
    };

    protected static void calculateAlphabetCombinations(List<String> combinationList, String prefix, String remainingDigits) {
        if (remainingDigits == null || remainingDigits.isEmpty()) {
            return;
        }
        int digit = Integer.parseInt(remainingDigits.substring(0, 1));
        if (remainingDigits.length() == 1) {
            for (String letter : DIAL_PAD_MAP[digit]) {
                combinationList.add(prefix + letter);
            }
        } else {
            for (String letter : DIAL_PAD_MAP[digit]) {
                calculateAlphabetCombinations(combinationList, prefix + letter, remainingDigits.substring(1));
            }
        }
    }

    public static LinkedList<String> retrieveCombinations(String digitInput) {
        LinkedList<String> combinationList = new LinkedList<>();
        if (digitInput != null && !digitInput.isEmpty()) {
            calculateAlphabetCombinations(combinationList,"",digitInput);
        }
        return combinationList;
    }


}
